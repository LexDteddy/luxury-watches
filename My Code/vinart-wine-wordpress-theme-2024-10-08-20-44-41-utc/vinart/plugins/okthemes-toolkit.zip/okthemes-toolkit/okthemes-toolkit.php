<?php
/**
 * Plugin Name: OKThemes Toolkit
 * Description: A Helper plugin for all OKThemes Wordpress Themes
 * Plugin URI: #
 * Author: OKThemes
 * Author URI: http://okthemes.com/
 * Version: 1.3
 * Text Domain: okthemes-toolkit
 * License: GPL2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * The Main Plugin class
 */
final class Okthemes_Toolkit {

    /**
     * Addon Version
     *
     * @since 1.0.0
     * @var string The Plugin version.
     */
    const version = '1.3';

    /**
     * Minimum PHP Version
     *
     * @since 1.0.0
     * @var string Minimum PHP version required to run the Plugin.
     */
    const MINIMUM_PHP_VERSION = '5.6';

    /**
     * List of compatible themes
     *
     * @since 1.0.0
     * @var array List of themes compatible with the plugin.
     */
    private $compatible_themes = ['vinart'];

    /**
     * Class Constructor
     */
    private function __construct() {
        $this->define_constants();

        add_action( 'admin_enqueue_scripts', [$this, 'scripts'] );
        add_action( 'plugins_loaded', [$this, 'init_plugin'] );
    }

    /**
     * Initializes a singleton instance
     *
     * @return \Okthemes_Toolkit
     */
    public static function init() {
        static $instance = false;

        if ( ! $instance ) {
            $instance = new self();
        }

        return $instance;
    }

    /**
     * Define the required plugin constants
     *
     * @return void
     */
    public function define_constants() {
        define( 'OKT_VERSION', self::version );
        define( 'OKT_FILE', __FILE__ );
        define( 'OKT_PATH', plugin_dir_path( OKT_FILE ) );
        define( 'OKT_URL', plugin_dir_url( OKT_FILE ) );
        define( 'OKT_ASSETS', untrailingslashit( OKT_URL . 'assets' ) );
        define( 'OKT_INCLUDES', untrailingslashit( OKT_PATH . 'includes' ) );
    }

    /**
     * Load Textdomain
     *
     * Load plugin localization files.
     *
     * Fired by `init` action hook.
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function i18n() {
        load_plugin_textdomain( 'okthemes-toolkit', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
    }

    /**
     * Initialize the plugin
     *
     * @return void
     */
    public function init_plugin() {
        if ( $this->is_compatible() ) {
            $this->include_files();
        }
    }

    public function scripts() {
        wp_enqueue_style( 'okthemes-toolkit-editor-style', OKT_ASSETS . '/css/style.css', '', '1.0' );
    }

    /**
     * Get current theme slug
     *
     * @access public
     * @static
     */
    public static function get_theme_slug() {
        return str_replace( '-child', '', wp_get_theme()->get( 'TextDomain' ) );
    }

    /**
     * Check Compatible
     *
     * @access public
     * @static
     *
     * @return boolean
     */
    public function theme_is_compatible() {
        $theme_name = self::get_theme_slug();
        return in_array($theme_name, $this->compatible_themes, true);
    }

    /**
     * Compatibility Checks
     *
     * Checks whether the site meets the addon requirement.
     *
     * @since 1.0.0
     * @access public
     */
    public function is_compatible() {
        // Check for required PHP version
        if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
            add_action( 'admin_notices', [$this, 'admin_notice_minimum_php_version'] );
            return false;
        }

        // Check For 'okthemes-toolkit' Theme install or active
        if ( ! $this->theme_is_compatible() ) {
            add_action( 'admin_notices', [$this, 'admin_notice_missing_main_theme'] );
            return false;
        }

        return true;
    }

    public function is_active_elementor() {
        if ( ! did_action( 'elementor/loaded' ) ) {
            return false;
        }

        return true;
    }

    /**
     * Include required plugin files
     *
     * @return void
     */
    public function include_files() {
        $theme_name = self::get_theme_slug();

        include_once OKT_INCLUDES . '/library/codestar-framework/codestar-framework.php';
        include_once OKT_INCLUDES . '/functions.php';

        include_once OKT_INCLUDES . '/themes/' . $theme_name . '/' . $theme_name . '-theme-options.php';
        include_once OKT_INCLUDES . '/themes/' . $theme_name . '/' . $theme_name . '-metaboxes.php';

        include_once OKT_INCLUDES . '/gutenberg/init.php';

        if ( $this->is_active_elementor() ) {
            include_once OKT_INCLUDES . '/elementor/init.php';
            include_once OKT_INCLUDES . '/elementor/template-builder/template-builder.php';
        }
    }

    /**
     * Admin notice
     *
     * Warning when the site doesn't have a minimum required PHP version.
     *
     * @since 1.0.0
     * @access public
     */
    public function admin_notice_minimum_php_version() {

        if ( isset( $_GET['activate'] ) ) {
            unset( $_GET['activate'] );
        }

        $message = sprintf(
            /* translators: 1: Plugin name 2: PHP 3: Required PHP version */
            esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'okthemes-toolkit' ),
            '<strong>' . esc_html__( 'OKThemes Toolkit', 'okthemes-toolkit' ) . '</strong>',
            '<strong>' . esc_html__( 'PHP', 'okthemes-toolkit' ) . '</strong>',
            self::MINIMUM_PHP_VERSION
        );

        printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

    }

    /**
     * Admin notice
     *
     * Warning when the site doesn't have Okthemes theme installed or activated.
     *
     * @since 1.0.0
     * @access public
     */
    public function admin_notice_missing_main_theme() {

        if ( isset( $_GET['activate'] ) ) {
            unset( $_GET['activate'] );
        }

        $message = sprintf(
            esc_html__( '"%1$s" plugin requires a compatible OKThemes theme to be installed and activated', 'okthemes-toolkit' ),
            '<strong>' . esc_html__( 'OKThemes Toolkit', 'okthemes-toolkit' ) . '</strong>'
        );

        printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
    }
}

/**
 * Initializes the main plugin
 *
 * @return void
 */
function okthemes_toolkit_loading() {
    return Okthemes_Toolkit::init();
}

// kick-off the plugin
okthemes_toolkit_loading();
?>
