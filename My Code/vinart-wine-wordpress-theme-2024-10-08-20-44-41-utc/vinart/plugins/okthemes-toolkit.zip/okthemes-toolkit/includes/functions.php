<?php
/**
 * Helper functions
 *
 */
defined( 'ABSPATH' ) || exit;


/* Add the number field to the complex array in CSF */
function add_number_to_complex_fields($fields) {
    $fields[] = 'number'; // Add 'number' to the array
    return $fields;
}
add_filter('csf_customize_complex_fields', 'add_number_to_complex_fields');


/*
Wrapper function for theme_name_get_icons() function from the theme

Wrapper Function: The okthemes_get_theme_icon function takes the icon name, 
constructs the function name based on the active theme's slug, checks if the function exists, and calls it.
If the function does not exist, it returns a fallback icon.

Using the Wrapper: okthemes_get_theme_icon('header-my-account')
*/

if ( ! function_exists( 'okthemes_get_theme_icon' ) ) {
    function okthemes_get_theme_icon( $icon_name ) {
        $theme_slug = Okthemes_Toolkit::get_theme_slug();
        $icon_function = $theme_slug . '_get_icons';
        if ( function_exists( $icon_function ) ) {
            return call_user_func( $icon_function, $icon_name );
        } else {
            // Provide a fallback or return empty if function does not exist
            return ''; // Example fallback
        }
    }
}
