<?php
namespace OkthemesToolkit\GutenbergAddon;

defined( 'ABSPATH' ) || exit;

/**
 * Okthemes Gutenberg Addon
 */
class Okthemes_Gutenberg_Addon {

    /**
     * The default path to elementor dir on this plugin.
     *
     * @var string
     */
    private $dir_path;

    /**
     * Instance
     *
     * @since 1.0.0
     *
     * @access private
     * @static
     */
    protected static $instance = null;

    /**
     * Instance
     *
     * Ensures only one instance of the class is loaded or can be loaded.
     *
     * @since 1.0.0
     *
     * @access public
     * @static
     */
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Initialize Addons
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function initialize() {
        $this->dir_path = plugin_dir_path( __FILE__ );

        // Initialize Gutenberg Addon
        $this->initialize_gutenberg();
    }

    /**
     * Initialize Gutenberg Addon
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function initialize_gutenberg() {
        // Gutenberg Blocks
        add_action('init', [$this, 'register_gutenberg_blocks']);

        // Enqueue Block Editor Assets
        add_action('enqueue_block_editor_assets', [$this, 'enqueue_block_editor_assets']);

        // Register custom block category filter
        add_filter('block_categories_all', [$this, 'filter_block_categories_when_post_provided'], 10, 2);
    }

    /**
     * Register Gutenberg Blocks
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function register_gutenberg_blocks() {

        register_block_type( 'okthemes/footer-contact', array(
            'editor_script' => 'okthemes-footer-contact-block'
        ) );

        register_block_type( 'okthemes/footer-visit-us', array(
            'editor_script' => 'okthemes-footer-visit-us-block'
        ) );

    }

    /**
     * Enqueue Block Editor Assets
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function enqueue_block_editor_assets() {
        wp_enqueue_script(
            'okthemes-footer-contact-block',
            plugins_url( '/blocks/footer-contact-block/index.js', __FILE__ ), // Corrected line
            array( 'wp-blocks', 'wp-element', 'wp-editor', 'wp-components' ),
            filemtime( plugin_dir_path( __FILE__ ) . '/blocks/footer-contact-block/index.js' ) // For versioning based on file modification time
        );

        wp_enqueue_script(
            'okthemes-footer-visit-us-block',
            plugins_url( '/blocks/footer-visit-us-block/index.js', __FILE__ ), // Corrected line
            array( 'wp-blocks', 'wp-element', 'wp-editor', 'wp-components' ),
            filemtime( plugin_dir_path( __FILE__ ) . '/blocks/footer-visit-us-block/index.js' ) // For versioning based on file modification time
        );
    }

    /**
     * Filter Block Categories
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function filter_block_categories_when_post_provided($block_categories, $editor_context) {
        if (!empty($editor_context->post)) {
            array_push(
                $block_categories,
                array(
                    'slug'  => 'okthemes-blocks',
                    'title' => __('OKThemes Blocks', 'okthemes-toolkit'),
                    'icon'  => null,
                )
            );
        }
        return $block_categories;
    }
    

}

Okthemes_Gutenberg_Addon::instance()->initialize();