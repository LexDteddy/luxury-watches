(function(blocks, element, blockEditor, components) {
    var el = element.createElement;
    var RichText = blockEditor.RichText;
    var URLInputButton = blockEditor.URLInputButton;
    var InnerBlocks = blockEditor.InnerBlocks;
    var InspectorControls = blockEditor.InspectorControls;

    blocks.registerBlockType('okthemes/footer-visit-us', {
        title: 'Footer Visit Us',
        icon: 'email',
        category: 'okthemes-blocks',
        attributes: {
            headingSmall: {
                type: 'string',
                source: 'html',
                selector: 'h6',
            },
            headingLarge: {
                type: 'string',
                source: 'html',
                selector: 'h2',
            },
            links: {
                type: 'string',
                source: 'html',
                selector: 'p.links',
            },
            details: {
                type: 'string',
                source: 'html',
                selector: 'p.details',
            }
            
        },
        edit: function(props) {

            return el(
                'div',
                { className: 'wp-block-group' },
                el(RichText, {
                    tagName: 'h6',
                    value: props.attributes.headingSmall,
                    onChange: function(newVal) {
                        props.setAttributes({ headingSmall: newVal });
                    },
                    placeholder: 'Small Heading',
                }),
                el(RichText, {
                    tagName: 'h2',
                    value: props.attributes.headingLarge,
                    onChange: function(newVal) {
                        props.setAttributes({ headingLarge: newVal });
                    },
                    placeholder: 'Large Heading',
                }),
                el(RichText, {
                    tagName: 'p',
                    className: 'links',
                    formattingControls: ['link'], // Enable link insertion
                    value: props.attributes.links,
                    onChange: function(newVal) {
                        props.setAttributes({ links: newVal });
                    },
                    placeholder: 'Link',
                }),
                el(RichText, {
                    tagName: 'p',
                    className: 'details',
                    value: props.attributes.details,
                    onChange: function(newVal) {
                        props.setAttributes({ details: newVal });
                    },
                    placeholder: 'Details',
                })
            );
        },
        save: function(props) {
            return el(
                'div',
                { className: 'wp-block-group' },
                el(RichText.Content, {
                    tagName: 'h6',
                    value: props.attributes.headingSmall,
                }),
                el(RichText.Content, {
                    tagName: 'h2',
                    value: props.attributes.headingLarge,
                }),
                el(RichText.Content, {
                    tagName: 'p',
                    className: 'links', // Class name for styling
                    value: props.attributes.links,
                }),
                el(RichText.Content, {
                    tagName: 'p',
                    className: 'details',
                    value: props.attributes.details,
                })
            );
        },
    });
})(window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components);

