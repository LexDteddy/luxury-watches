<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access directly.
/**
 *
 * Field: number
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! class_exists( 'CSF_Field_number' ) ) {
  class CSF_Field_number extends CSF_Fields {

    public function __construct( $field, $value = '', $unique = '', $where = '', $parent = '' ) {
      parent::__construct( $field, $value, $unique, $where, $parent );
    }

    public function render() {

      $args = wp_parse_args($this->field, array(
        'min'  => 'any',
        'max'  => 'any',
        'step' => 'any',
        'unit' => false, // Changed to support a boolean
        'unit_options' => array('px' => 'px', 'em' => 'em', 'rem' => 'rem', '%' => '%', 'vw' => 'vw') // Default unit options
      ));
  
      echo $this->field_before();
      echo '<div class="csf--wrap">';
      
  
      // Number input
      echo '<input type="number" name="'. esc_attr($this->field_name('[number]')) .'" value="'. esc_attr($this->value['number'] ?? $args['default']) .'"'. $this->field_attributes() .' min="'. esc_attr($args['min']) .'" max="'. esc_attr($args['max']) .'" step="'. esc_attr($args['step']) .'"/>';
  
      // Unit dropdown
      if ($args['unit']) {
        $selected_unit = $this->value['unit'] ?? $args['default_unit'] ?? 'px';
        echo $this->create_select($args['unit_options'], $this->field_name('[unit]'), '', false, $selected_unit);
      }
  
      echo '</div>';
      echo $this->field_after();
    }

    public function output() {
      $output    = '';
      $elements  = ( is_array( $this->field['output'] ) ) ? $this->field['output'] : array_filter( (array) $this->field['output'] );
      $important = ( ! empty( $this->field['output_important'] ) ) ? '!important' : '';
      $mode      = ( ! empty( $this->field['output_mode'] ) ) ? $this->field['output_mode'] : 'width';
  
      // Check if $this->value is an array and has 'number' and 'unit' keys
      if ( ! empty( $elements ) && isset( $this->value['number'] ) ) {
          $value = $this->value['number']; // Get the number
          $unit = isset($this->value['unit']) ? $this->value['unit'] : 'px'; // Get the unit or default to 'px'
  
          foreach ( $elements as $key_property => $element ) {
              if ( is_numeric( $key_property ) ) {
                  if ( $mode ) {
                      $output = implode( ',', $elements ) .'{'. $mode .':'. $value . $unit . $important .';}';
                  }
                  break;
              } else {
                  $output .= $element .'{'. $key_property .':'. $value . $unit . $important .'}';
              }
          }
      }
  
      $this->parent->output_css .= $output;
  
      return $output;
  }
  

    // Add create_select method if not already present
    public function create_select( $options, $name, $placeholder = '', $is_multiple = false, $selected_value = '' ) {
      $output  = '<select name="'. esc_attr( $name ) .'">';
      foreach ( $options as $option_key => $option_value ) {
        $selected = ($option_key == $selected_value) ? ' selected' : '';
        $output .= '<option value="'. esc_attr( $option_key ) .'"'. $selected .'>'. esc_html( $option_value ) .'</option>';
      }
      $output .= '</select>';
      return $output;
    }

  }
}
