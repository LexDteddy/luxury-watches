document.addEventListener('DOMContentLoaded', function() {
    const selectors = {
        button: '[data-hover-target]',
        image: '[data-collection-image]',
    };

    const attributes = {
        target: 'data-hover-target',
    };

    const classes = {
        visible: 'is-visible',
        selected: 'is-selected',
    };

    document.querySelectorAll(selectors.button).forEach(button => {
        button.addEventListener('mouseenter', (e) => {
            const targetId = e.currentTarget.getAttribute(attributes.target);
            const container = e.currentTarget.closest('.images-list-hover');
            const target = container.querySelector(`#${targetId}:not(.${classes.visible})`);
            const buttonSelected = container.querySelector(`${selectors.button}.${classes.selected}`);
            const imageVisible = container.querySelector(`${selectors.image}.${classes.visible}`);

            if (target) {
                imageVisible?.classList.remove(classes.visible);
                buttonSelected?.classList.remove(classes.selected);

                target.classList.add(classes.visible);
                e.currentTarget.classList.add(classes.selected);
            }
        });
    });
});

