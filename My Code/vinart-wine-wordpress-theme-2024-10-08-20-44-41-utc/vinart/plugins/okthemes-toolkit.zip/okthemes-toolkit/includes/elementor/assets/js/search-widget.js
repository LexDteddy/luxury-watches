// Get the necessary elements
const triggerButtons = document.querySelectorAll('.popup-trigger');
const closeButtons = document.querySelectorAll('.popup-close');

// Function to toggle the popup
function togglePopup(event) {
  const popupId = event.currentTarget.getAttribute('data-popup');
  const popup = document.getElementById(popupId);
  
  //if (popup) {
    popup.classList.toggle('show');
  //}
}

// Event listener for the trigger buttons
if (triggerButtons) {
  triggerButtons.forEach((button) => {
    button.addEventListener('click', togglePopup);
  });
}

// Event listener for the close buttons
if (closeButtons) {
  closeButtons.forEach((button) => {
    button.addEventListener('click', togglePopup);
  });
}