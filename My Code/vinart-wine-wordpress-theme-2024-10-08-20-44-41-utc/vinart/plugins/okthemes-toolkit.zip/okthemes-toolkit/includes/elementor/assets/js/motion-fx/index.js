import MotionFXHandler from './module';
//import MotionFXEditor from './motion-fx-editor';

class MotionFXModule extends elementorModules.Module {
  constructor() {
    super();

    this.init();
  }

  init() {
    elementorFrontend.hooks.addAction('frontend/element_ready/global', ($element) => {
      elementorFrontend.elementsHandler.addHandler(MotionFXHandler, { $element });
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {

  jQuery(window).on('elementor/frontend/init', () => {
    new MotionFXModule();
  });
  
});
