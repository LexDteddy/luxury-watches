jQuery(window).on('elementor/frontend/init', () => {
    
    var videoLightbox = GLightbox({
        selector: '.glightbox-video'
    });

});
