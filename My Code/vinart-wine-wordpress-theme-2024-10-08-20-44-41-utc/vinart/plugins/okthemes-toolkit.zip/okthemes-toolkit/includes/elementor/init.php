<?php
namespace OkthemesToolkit\ElementorAddon;

defined( 'ABSPATH' ) || exit;

use Elementor\Plugin;

/**
 * Okthemes Elementor Addon
 */
class Okthemes_Elementor_Addon {

    /**
     * The default path to elementor dir on this plugin.
     *
     * @var string
     */
    private $dir_path;

    /**
     * Instance
     *
     * @since 1.0.0
     *
     * @access private
     * @static
     */
    protected static $instance = null;

    /**
     * Instance
     *
     * Ensures only one instance of the class is loaded or can be loaded.
     *
     * @since 1.0.0
     *
     * @access public
     * @static
     */
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Initialize Addons
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function initialize() {
        $this->dir_path = plugin_dir_path( __FILE__ );

        add_action( 'elementor/init', [$this, 'elementor_init'] );
    }

    /**
     * Initialize Elementor Action
     *
     * Load the plugin only after Elementor are loaded.
     *
     * Fired by `plugins_loaded` action hook.
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function elementor_init() {

        // Add New Elementor Categories
        add_action( 'elementor/elements/categories_registered', [$this, 'init_categories'] );

        // Register New Widgets
        add_action( 'elementor/widgets/register', [$this, 'init_widgets'] );

        //Register and enqueue scripts
        add_action( 'elementor/frontend/after_register_scripts', [ $this, 'register_frontend_scripts' ] );
        add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'enqueue_frontend_scripts' ] );

        //Enqueue styles
        add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'enqueue_styles' ] );

        // Initialize Custom Modules
        if ( ! class_exists( 'ElementorPro\Modules\ThemeBuilder\Module' ) ) {
            $this->init_modules();
        }        
        //Initialize Injections
        require $this->dir_path .'injections/button-widget.php';
    }

    /**
	 * Register Scripts After Elementor Scripts
	 * 
	 * @since 1.0.0
	 */
	public function register_frontend_scripts() {

        wp_register_script(
			'okthemes-lightbox',
			OKT_URL . '/assets/js/glightbox.min.js',
			[
				'elementor-frontend',
				'jquery'
			],
			OKT_VERSION,
			true // in_footer
		);

		wp_register_script(
			'okthemes-sticky',
			OKT_URL . '/includes/elementor/assets/js/sticky/sticky.js',
			[
				'elementor-frontend',
				'jquery'
			],
			OKT_VERSION,
			true // in_footer
		);
        wp_register_script(
			'okthemes-sticky-el',
			OKT_URL . '/includes/elementor/assets/js/sticky/sticky-el.js',
			[
				'elementor-frontend',
				'jquery'
			],
			OKT_VERSION,
			true // in_footer
		);

        // Register the Webpack runtime
        wp_register_script(
            'okthemes-webpack-runtime',
            OKT_URL . 'includes/elementor/assets/js/motion-fx/build/runtime.bundle.js',
            [],
            OKT_VERSION,
            true // in_footer
        );

        // Register the bundled motion-fx script
        wp_register_script(
            'okthemes-motion-fx',
            OKT_URL . 'includes/elementor/assets/js/motion-fx/build/motion-fx.bundle.js',
            ['okthemes-webpack-runtime', 'elementor-frontend', 'jquery'],
            OKT_VERSION,
            true // in_footer
        );

        // Register the bundled motion-fx-editor script
        wp_register_script(
            'okthemes-motion-fx-editor',
            OKT_URL . 'includes/elementor/assets/js/motion-fx/build/motion-fx-editor.bundle.js',
            ['okthemes-webpack-runtime', 'elementor-editor'],
            OKT_VERSION,
            true // in_footer
        );

        wp_register_script(
			'okthemes-search-widget',
			OKT_URL . '/includes/elementor/assets/js/search-widget.js',
			[
				'elementor-frontend',
				'jquery'
			],
			OKT_VERSION,
			true // in_footer
		);

        wp_register_script(
			'okthemes-cart-drawer',
			OKT_URL . '/includes/elementor/assets/js/cart-drawer.js',
			[
				'elementor-frontend',
				'jquery'
			],
			OKT_VERSION,
			true // in_footer
		);

        wp_register_script(
			'okthemes-play-video',
			OKT_URL . '/includes/elementor/assets/js/play-video.js',
			[
				'jquery',
				'elementor-dialog',
			],
			OKT_VERSION,
			true // in_footer
		);
        wp_register_script(
			'okthemes-scrolling-text',
			OKT_URL . '/includes/elementor/assets/js/scrolling-text.js',
			[
				'jquery'
			],
			OKT_VERSION,
			true // in_footer
		);

        wp_register_script(
			'okthemes-images-list-hover',
			OKT_URL . '/includes/elementor/assets/js/images-list-hover.js',
			[
				'jquery'
			],
			OKT_VERSION,
			true // in_footer
		);

	}

    /**
	 * Enqeueue Scripts After Elementor Scripts
	 * 
	 * @since 1.0.0
	 */
	public function enqueue_frontend_scripts() {
		wp_enqueue_script( 'okthemes-lightbox' );
        wp_enqueue_script( 'okthemes-sticky' );
        wp_enqueue_script( 'okthemes-sticky-el' );
        
        wp_enqueue_script( 'okthemes-motion-fx' );
        //wp_enqueue_script( 'okthemes-motion-fx-editor' );

        wp_enqueue_script( 'okthemes-search-widget' );
        wp_enqueue_script( 'okthemes-cart-drawer' );
        wp_enqueue_script( 'okthemes-play-video' );
        wp_enqueue_script( 'okthemes-scrolling-text' );
        wp_enqueue_script( 'okthemes-images-list-hover' );
	}

    /**
	 * Enqueue Frontend Styles
	 * 
	 * @since 1.0.0
	 */
	public function enqueue_styles() {

        wp_enqueue_style(
			'okthemes-lightbox',
			OKT_URL . '/assets/css/glightbox.min.css',
			[],
			OKT_VERSION
		);

		wp_enqueue_style(
			'okthemes-search-widget',
			OKT_URL . '/includes/elementor/assets/css/search-widget.css',
			[],
			OKT_VERSION
		);

        wp_enqueue_style(
			'okthemes-cart-drawer',
			OKT_URL . '/includes/elementor/assets/css/cart-drawer.css',
			[],
			OKT_VERSION
		);

        wp_enqueue_style(
			'okthemes-price-list',
			OKT_URL . '/includes/elementor/assets/css/price-list.css',
			[],
			OKT_VERSION
		);

        wp_enqueue_style(
			'okthemes-play-video',
			OKT_URL . '/includes/elementor/assets/css/play-video.css',
			[],
			OKT_VERSION
		);

        wp_enqueue_style(
			'okthemes-pricing-table',
			OKT_URL . '/includes/elementor/assets/css/pricing-table.css',
			[],
			OKT_VERSION
		);

        wp_enqueue_style(
			'okthemes-advanced-heading',
			OKT_URL . '/includes/elementor/assets/css/advanced-heading.css',
			[],
			OKT_VERSION
		);

        wp_enqueue_style(
			'okthemes-simple-link',
			OKT_URL . '/includes/elementor/assets/css/simple-link.css',
			[],
			OKT_VERSION
		);

        wp_enqueue_style(
			'okthemes-scrolling-text',
			OKT_URL . '/includes/elementor/assets/css/scrolling-text.css',
			[],
			OKT_VERSION
		);

        wp_enqueue_style(
			'okthemes-images-list-hover',
			OKT_URL . '/includes/elementor/assets/css/images-list-hover.css',
			[],
			OKT_VERSION
		);

	}

    /**
     * Widgets Category
     *
     * @since 1.0.0
     * @access public
     */
    public function init_categories( $elements_manager ) {
        $categories = [];

        $categories['okthemes_elements'] = [
            'title' => esc_html__( 'OKThemes Elements', 'okthemes-toolkit' ),
            'icon'  => 'fa fa-smile-o',
        ];

        $old_categories = $elements_manager->get_categories();
        $categories     = array_merge( $categories, $old_categories );

        $set_categories = function ( $categories ) {
            $this->categories = $categories;
        };

        $set_categories->call( $elements_manager, $categories );
    }

    /**
     * Init Widgets
     *
     * Include widgets files and register them
     *
     * @since 1.0.0
     * @access public
     */
    public function init_widgets() {

        $widgets_manager = Plugin::instance()->widgets_manager;

        foreach (glob($this->dir_path . 'widgets/' . '*.php') as $file_name) {

            $base        = basename( str_replace( '.php', '', $file_name ) );
            $class       = ucwords( str_replace( '-', ' ', $base ) );
            $class       = str_replace( ' ', '_', $class );
            $class       = sprintf( 'OkthemesToolkit\ElementorAddon\Widgets\%s', $class );

            // Require Files
            require_once $file_name;

            // Class File
            if ( class_exists( $class ) ) {
                $widgets_manager->register( new $class );
            }
        }
    }

    /**
     * Initialize Custom Modules
     *
     * @since 1.0.0
     * @access public
     */

    public function init_modules() {

        foreach (glob($this->dir_path . 'modules/' . '*.php') as $file_name) {
            $base  = basename(str_replace('.php', '', $file_name));
            $class = ucwords(str_replace('-', ' ', $base));
            $class = str_replace(' ', '_', $class);
            $class = sprintf('OkthemesToolkit\ElementorAddon\Modules\%s', $class);

            // Class File
            require_once $file_name;

            if (class_exists($class)) {
                new $class();
            }
        }
    }
  

}

Okthemes_Elementor_Addon::instance()->initialize();

